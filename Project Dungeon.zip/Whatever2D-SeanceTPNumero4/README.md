# Projet pédagogique pour alternant 2D

Développé à l'hiver 2023

Ce TP est constitué de 4 séances de découverte de la POO suivis de deux séances de conception.

![](./src/TP2D/TP2D-__TP2D_s_Class_Diagram____.png)
