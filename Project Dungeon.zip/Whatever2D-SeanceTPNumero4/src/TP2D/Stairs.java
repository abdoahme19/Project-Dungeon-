package TP2D;

import java.awt.*;

public class Stairs extends SolidThings {

    public Stairs(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

    public Stairs(int x, int y, Image image) {
        super(x, y, image);
    }
}
