package TP2D;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class MainInterface extends JFrame implements KeyListener {
    TileManager tileManager = new TileManager(48,48,"./img/tileSet.png");
    Dungeon dungeon = null;
    int currentLevel = 1;
    Hero hero = Hero.getInstance();

    public MainInterface() throws HeadlessException {
        super();
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        dungeon = getDungeon(currentLevel);
        this.addKeyListener(this);

        ActionListener animationTimer=new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                repaint();
                final int speed= hero.isRunningMode() ? 20 : 10;
                if (hero.isWalking()){
                    switch (hero.getOrientation()){
                        case LEFT:  hero.moveIfPossible(-speed,0,dungeon);
                            break;
                        case RIGHT: hero.moveIfPossible(speed,0,dungeon);
                            break;
                        case UP:    hero.moveIfPossible(0,-speed,dungeon);
                            break;
                        case DOWN:  hero.moveIfPossible(0,speed,dungeon);
                            break;

                    }

                    if (hero.isTakingStairs()) {
                        if (currentLevel == 1) {
                            currentLevel = 2;
                        }
                        else {
                            currentLevel = 1;
                        }

                        dungeon = getDungeon(currentLevel);
                    }
                }
            }
        };
        Timer timer = new Timer(50,animationTimer);
        timer.start();
    }

    public static void main(String[] args){
        MainInterface mainInterface = new MainInterface();
    }

    public Dungeon getDungeon(int level) {
        Dungeon dungeon = new Dungeon("./gameData/level" + level + ".txt",tileManager);
        GameRender panel = new GameRender(dungeon,hero);
        this.getContentPane().removeAll();
        this.getContentPane().add(panel);
        this.setVisible(true);
        this.setSize(new Dimension(dungeon.getWidth()* tileManager.getWidth(), dungeon.getHeight()*tileManager.getHeigth()));
        return dungeon;
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()){
            case KeyEvent.VK_LEFT:
                hero.setOrientation(Orientation.LEFT);
                hero.setWalking(true);
                break;
            case KeyEvent.VK_RIGHT:
                hero.setOrientation(Orientation.RIGHT);
                hero.setWalking(true);
                break;
            case KeyEvent.VK_UP:
                hero.setOrientation(Orientation.UP);
                hero.setWalking(true);
                break;
            case KeyEvent.VK_DOWN:
                hero.setOrientation(Orientation.DOWN);
                hero.setWalking(true);
                break;
            case KeyEvent.VK_SPACE:
                hero.setRunningMode(!hero.isRunningMode());
                break;
        }
        this.repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {
        hero.setWalking(false);
    }
}
